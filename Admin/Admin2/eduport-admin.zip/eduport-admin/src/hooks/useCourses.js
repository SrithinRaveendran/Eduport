import { useState, useEffect, useCallback } from "react";
import { API } from "../constants";

export function useCourses() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetchError, setFetchError] = useState("");

  const fetchCourses = useCallback(async () => {
    setLoading(true);
    setFetchError("");
    try {
      const res = await fetch(API);
      if (!res.ok) throw new Error("Failed to fetch: " + res.status);
      const data = await res.json();
      setCourses(Array.isArray(data) ? data : data.courses || []);
    } catch (e) {
      setFetchError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  return { courses, loading, fetchError, fetchCourses };
}
